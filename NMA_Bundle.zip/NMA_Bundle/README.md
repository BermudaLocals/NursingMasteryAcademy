# 🩺 Nursing Mastery Academy - Supplemental Simulation

**The Practice Gym for Nursing Students - Master Clinical Judgment, Not Just Textbooks**

> **Non-accredited supplemental education. Not a nursing program. Not affiliated with NCSBN, ANCC, or any Board of Nursing. Does not provide licensure, CEUs, or clinical hours.**

Supplemental simulation training aligned to NCSBN Clinical Judgment Measurement Model. For TEAS, CNA, LPN, RN students.

## Live Demo
See index.html - includes Triage Engine Red Zone + Med-Safety Loop + AI Director with iOS fallback

## 3 Legal Tiers (Covers 7 Avatars)

### Tier 1: Foundations Academy - $97
For: Pre-Nursing/TEAS, CNA Student, LPN/LVN
- TEAS prep, CNA challenge prep (check state rules), Vital Signs Red Zone, 5 Rights, ADLs, Infection Control
- Outcome: Pass entrance/CNA exam faster

### Tier 2: Clinical Mastery Academy - $297 or $49/mo [CORE - BUILD FIRST]
For: RN Student ADN/BSN, New Grad RN
- Aligned to NCSBN CJMM: Recognize Cues, Analyze Cues, Prioritize Hypotheses, Generate Solutions, Take Action, Evaluate Outcomes
- 200 NGN case studies: Med-Surg 40%, Pharm 20%, OB 10%, Peds 10%, Mental Health 10%, Leadership 10%
- Formats: Bow-tie, Matrix, Trend, Cloze, Drag-drop
- AI Director Web Speech API + text fallback for iOS Safari
- Outcome: Master clinical judgment and pass Next Gen NCLEX

### Tier 3: Pro Vault - $497 + School License $3k/year
For: Working RN / Charge / RN to BSN / Pre-NP
- Renamed from Doctor's Vault to Advanced Clinical Reasoning Vault
- Label: "For educational reasoning only - not medical advice"
- Modules: Charge triage, Rapid Response, Code Blue, SBAR, Delegation, Precepting
- Outcome: Think like a charge nurse

## Best Demo Videos (with creator credit)

1. **Master Clinical Judgment for the Next Generation NCLEX** - Creator: NCLEX RN Core Review - Andrews - https://www.youtube.com/watch?v=V_5xgAx-07Q
2. **Next Gen NCLEX Case Study: Appendicitis** - Creator: Nursing Student Avenger - https://www.youtube.com/watch?v=-LtfLQxepmM
3. **Next Gen NCLEX Case Study 6/6** - Creator: Nursing Student Avenger - https://www.youtube.com/watch?v=CDRaKmmpmBA
4. **Official NCSBN NGN Talks** - Creator: NCSBN - Jacklyn Currier & Jenn Keating - https://www.ncsbn.org/exams/next-generation-nclex/ngn-talks.page
5. **Triage Demo** - Creator: Medley AI (ki-smile/triage-medley) - https://triage.medleyai.org/

## Legal
Certificate: "Certificate of Completion - Simulation Training. Non-accredited. Does not provide licensure or qualify you to sit for NCLEX."

Footer: For educational purposes only. Not an accredited nursing program, not affiliated with NCSBN, ANCC, or any Board of Nursing. Does not provide licensure, CEUs, or clinical hours.

## SEO - US Legal
Use: NCLEX prep, Next Gen NCLEX practice, clinical judgment practice, TEAS prep, CNA exam prep, nursing simulation
Do NOT use: Accelerated Nursing Degree, Starter Doctor Course, Digital Residency, Credential of Excellence, Doctor's Vault

## Files
- index.html: US-compliant landing with demo videos + Triage Engine
- main.js: Clinical Brain v2 with iOS fallback
- style.css: Navy #0A1931 + Gold #C5A880
- legal/: disclaimers
- curriculum/: curriculum_map.json
- deploy_to_github.sh: push script
- test_workings.sh: QA agent

© 2026 Nursing Mastery Academy

#!/bin/bash
# Nursing Mastery Academy - US Compliant Push to GitHub
# Repo: bermudalocals/nursingmasteryacademy
# Run from your local machine where you have git + gh cli or PAT

set -e

REPO_URL="https://github.com/bermudalocals/nursingmasteryacademy.git"
WORK_DIR="nursingmasteryacademy"
BRANCH="main"

echo "=== Nursing Mastery Academy - Deploy 3-Tier US Compliant Build ==="

# 1. Clone or update
if [ -d "$WORK_DIR" ]; then
  echo "[*] Updating existing repo..."
  cd $WORK_DIR
  git checkout $BRANCH
  git pull origin $BRANCH
  cd ..
else
  echo "[*] Cloning repo..."
  git clone $REPO_URL
fi

cd $WORK_DIR

# 2. Backup old files
mkdir -p backups
cp index.html backups/index.html.bak.$(date +%s) 2>/dev/null || echo "No old index.html to backup"
cp README.md backups/README.md.bak.$(date +%s) 2>/dev/null || true

# 3. Download new landing page artifact
# You downloaded from Meta AI preview: nursing_mastery_academy_tier_agentic_artifact...
# Place it as index.html - this script expects you put the downloaded file at ../new_index.html
# If you ran this from the folder containing the downloaded artifact:
if [ -f "../nursing_mastery_academy_tier_agentic_artifact_1_c3656349d81d.html" ]; then
  cp ../nursing_mastery_academy_tier_agentic_artifact_1_c3656349d81d.html index.html
  echo "[*] New index.html copied from artifact"
elif [ -f "./new_landing.html" ]; then
  cp ./new_landing.html index.html
  echo "[*] New index.html copied from ./new_landing.html"
else
  echo "[!] Place your new landing page file as ../nursing_mastery_academy_tier...html or ./new_landing.html"
  echo "    Download from: Meta AI artifact preview > Save As"
  # We will generate a minimal compliant index.html inline as fallback
  cat > index.html <<'HTML'
<!DOCTYPE html>
<html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width"><title>Nursing Mastery Academy - Supplemental Simulation</title></head>
<body><h1>See full React build in App.tsx - run npm run build</h1><p>Place artifact HTML here</p></body></html>
HTML
fi

# 4. Create US-compliant README.md
cat > README.md <<'MD'
# 🩺 Nursing Mastery Academy - Supplemental Simulation

**The Practice Gym for Nursing Students - Master Clinical Judgment, Not Just Textbooks**

Supplemental simulation training aligned to NCSBN Clinical Judgment Model. For TEAS, CNA, LPN, RN students.

> **Non-accredited supplemental education. Not a nursing program. Not affiliated with NCSBN, ANCC, or any Board of Nursing. Does not provide licensure, CEUs, or clinical hours.**

## 3 Legal Tiers (Covers 7 Avatars)

### Tier 1: Foundations Academy - $97
For: Pre-Nursing/TEAS, CNA Student, LPN/LVN
- TEAS prep, CNA challenge prep (check state rules), Vital Signs Red Zone, 5 Rights, ADLs, Infection Control
- Outcome: Pass entrance/CNA exam faster

### Tier 2: Clinical Mastery Academy - $297 or $49/mo [CORE]
For: RN Student ADN/BSN, New Grad RN
- Aligned to NCSBN CJMM: Recognize Cues, Analyze Cues, Prioritize Hypotheses, Generate Solutions, Take Action, Evaluate Outcomes
- Med-Surg, Pharm, OB, Peds, Mental Health, Leadership - 200 NGN case studies
- AI Director with text fallback for iOS
- Outcome: Master clinical judgment and pass Next Gen NCLEX

### Tier 3: Pro Vault - $497 + School License $3k/yr
For: Working RN / Charge / RN to BSN / Pre-NP
- Renamed from Doctor's Vault to Advanced Clinical Reasoning Vault
- Charge triage, Rapid Response, Code Blue, SBAR - For educational reasoning only - not medical advice
- Outcome: Think like a charge nurse

## Legal
Certificate: "Certificate of Completion - Simulation Training. Non-accredited. Does not provide licensure or qualify you to sit for NCLEX."

Footer: For educational purposes only. Not an accredited nursing program, not affiliated with NCSBN, ANCC, or any Board of Nursing. Does not provide licensure, CEUs, or clinical hours.

## Tech
- index.html: US-compliant landing
- style.css: Navy #0A1931 + Gold #C5A880 luxury-medical
- main.js: Clinical Brain with Web Speech API + text fallback
- /legal/: disclaimers
- /curriculum/: curriculum_map.json

## SEO (US Legal)
Use: NCLEX prep, Next Gen NCLEX practice, clinical judgment practice, TEAS prep, CNA exam prep, nursing simulation
Do NOT use: Accelerated Nursing Degree, Starter Doctor Course, Digital Residency, Credential of Excellence

## Credibility
Replace CCO with: Reviewed by [Name], MSN, RN, Licensed in [State] - 10 years Med-Surg

© 2026 Nursing Mastery Academy
MD
echo "[*] README.md rewritten to US-compliant version"

# 5. Create legal folder
mkdir -p legal curriculum

cat > legal/disclaimer.md <<'DISC'
# Legal Disclaimer - Nursing Mastery Academy

**For educational purposes only.**

Nursing Mastery Academy is a supplemental simulation and test-preparation product. We are not an accredited nursing program, not affiliated with NCSBN, ANCC, or any Board of Nursing.

We do not provide:
- Nursing licensure
- Academic credit
- Continuing education credits (CEUs)
- Clinical hours
- Qualification to sit for NCLEX

**Advanced Clinical Reasoning Vault (formerly Doctor's Vault):**
For educational reasoning only - not medical advice. Does not establish provider-patient relationship. Do not use to diagnose or treat patients. Always follow your school, employer, and Board of Nursing policies.

**Medical Translations:**
Our Global Multi-Language Engine (English, Spanish, French, Portuguese) translations are verified by certified medical translators, especially for dosages, ADL instructions, and Red Zone vital sign cues. Auto-translate is not used for medical content.

**CNA Challenge:**
Many states allow challenging the CNA exam without school, many do not. We provide knowledge prep only. Check your state DHHS / Board of Nursing rules. We do not provide CNA license.

**Certificate Wording (all tiers):**
"Certificate of Completion - Simulation Training. Non-accredited. Does not provide licensure or qualify you to sit for NCLEX."

**Liability:**
Results vary. Always follow your school, employer, and Board of Nursing policies. For medical emergencies, call 911.

**Company:**
Form US LLC/C-Corp (Wyoming or Delaware + registered agent) before taking US payments. Get liability insurance for education product.

**Contact for Content Review:**
Reviewed by [First Last], MSN, RN, Licensed in [State]
Additional Review by [First Last], BSN, RN

Date: 2026
DISC

cat > legal/terms.md <<'TERMS'
# Terms of Service - Placeholder
Replace with lawyer-reviewed TOS covering refunds, access, no guarantee of passing NCLEX, educational use only, user conduct, IP.
TERMS

cat > legal/privacy.md <<'PRIV'
# Privacy Policy - Placeholder
Replace with lawyer-reviewed Privacy Policy covering data collection, Stripe, analytics, GDPR/CCPA, student data FERPA considerations.
PRIV

# 6. Curriculum map
cat > curriculum/curriculum_map.json <<'JSON'
{
  "tiers": {
    "tier1_foundations": {
      "price": "$97",
      "avatars": ["Pre-Nursing/TEAS", "CNA Student", "LPN/LVN"],
      "outcome": "Pass entrance / CNA exam faster",
      "modules": [
        {"id": "TEAS-Math", "cjmm": "Analyze Cues", "hours": 5},
        {"id": "TEAS-Science", "cjmm": "Recognize Cues", "hours": 5},
        {"id": "CNA-Vitals-RedZone", "cjmm": "Recognize Cues", "sim": "Triage Engine O2<90% SBP<90 HR>120"},
        {"id": "CNA-ADLs", "cjmm": "Take Action", "sim": "Infection Control"},
        {"id": "MedSafety-5Rights", "cjmm": "Take Action", "sim": "Med-Safety Loop"}
      ]
    },
    "tier2_clinical_mastery": {
      "price": "$297 or $49/mo",
      "avatars": ["RN Student ADN/BSN", "New Grad RN"],
      "outcome": "Master clinical judgment and pass Next Gen NCLEX",
      "alignment": "NCSBN Clinical Judgment Measurement Model",
      "modules": {
        "Med-Surg": {"count": 80, "formats": ["Bow-tie", "Matrix", "Trend"]},
        "Pharm": {"count": 40, "formats": ["Matrix", "Cloze"]},
        "OB": {"count": 20, "formats": ["Case Study"]},
        "Peds": {"count": 20, "formats": ["Case Study"]},
        "Mental Health": {"count": 20, "formats": ["Trend"]},
        "Leadership": {"count": 20, "formats": ["Bow-tie"]}
      },
      "tech": "AI Director Web Speech API + text fallback for iOS Safari"
    },
    "tier3_pro_vault": {
      "price": "$497 + School License $3k/year",
      "avatars": ["Working RN/Charge", "RN to BSN/NP Track"],
      "old_name": "Doctor's Vault",
      "new_name": "Advanced Clinical Reasoning Vault",
      "label": "For educational reasoning only - not medical advice",
      "modules": ["Charge Triage", "Rapid Response", "Code Blue", "SBAR Handoff", "Delegation RN/LPN/UAP", "Precepting"]
    }
  },
  "banned_terms": ["Accelerated Nursing Degree", "Starter Doctor Course", "Digital Residency", "Credential of Excellence", "Doctor's Vault"],
  "required_terms": ["Supplemental", "Non-accredited", "Does not provide licensure", "For educational purposes only", "Not affiliated with NCSBN"]
}
JSON

echo "[*] Legal and curriculum files created"

# 7. Fix main.js - add iOS fallback
if [ -f "main.js" ]; then
  cp main.js backups/main.js.bak.$(date +%s)
fi

cat > main.js <<'JS'
// Nursing Mastery Academy - Clinical Brain - US Compliant v2
// Fixes: iOS Safari fallback, NCSBN CJMM mapping, no degree claims

const NCSBN_STEPS = [
  "Recognize Cues", "Analyze Cues", "Prioritize Hypotheses",
  "Generate Solutions", "Take Action", "Evaluate Outcomes"
];

let currentStep = 0;
let progress = JSON.parse(localStorage.getItem('nma_progress') || '{}');

function directorSpeak(text, stepName) {
  const fallback = document.getElementById('director-text-fallback');
  const status = document.getElementById('director-status');
  if (fallback) {
    fallback.innerText = `[${stepName || NCSBN_STEPS[currentStep]}] ${text}`;
    fallback.style.display = 'block';
  }
  if (status) status.innerText = `Step: ${stepName || NCSBN_STEPS[currentStep]}`;

  // Voice if available, else text only
  if ('speechSynthesis' in window) {
    try {
      window.speechSynthesis.cancel();
      const utter = new SpeechSynthesisUtterance(text);
      utter.rate = 0.95;
      window.speechSynthesis.speak(utter);
    } catch (e) {
      console.log('Voice failed, using text fallback', e);
    }
  }
}

function checkRedZone(vitals) {
  // Triage Engine - maps to Recognize Cues
  const red = [];
  if (vitals.spo2 < 90) red.push('O2 <90% RED ZONE');
  if (vitals.sbp < 90 || vitals.sbp > 180) red.push('BP RED ZONE');
  if (vitals.hr < 50 || vitals.hr > 120) red.push('HR RED ZONE');
  if (vitals.temp > 101.5) red.push('Temp RED ZONE');
  return red;
}

function check5Rights(order, admin) {
  // Med-Safety Loop - maps to Take Action
  const errors = [];
  if (order.patient !== admin.patient) errors.push('Right Patient failed');
  if (order.drug !== admin.drug) errors.push('Right Drug failed');
  if (order.dose !== admin.dose) errors.push('Right Dose failed');
  if (order.route !== admin.route) errors.push('Right Route failed');
  return errors;
}

// Init
document.addEventListener('DOMContentLoaded', () => {
  console.log('NMA v2 US Compliant loaded - Supplemental only');
  directorSpeak('Welcome to the practice gym. We practice clinical judgment aligned to NCSBN model. Not a nursing program.', 'Recognize Cues');
});
JS

echo "[*] main.js patched with iOS fallback + NCSBN mapping"

# 8. Git add/commit/push
git add index.html README.md main.js legal/ curriculum/ 2>/dev/null
git add style.css 2>/dev/null || true

echo ""
echo "=== Git Status ==="
git status

echo ""
read -p "Push to GitHub now? (y/n): " -n 1 -r
echo
if [[ $REPLY =~ ^[Yy]$ ]]; then
  git commit -m "feat: US-compliant 3-tier rebuild - Foundations \$97, Clinical Mastery \$297, Pro Vault \$497 - NCSBN CJMM alignment, remove degree/residency claims, add legal disclaimers, iOS fallback, Spanish verified"
  git push origin $BRANCH
  echo "[✓] Pushed to $REPO_URL"
else
  echo "[*] Not pushed. Review files then run: git commit -m 'feat: US-compliant rebuild' && git push"
fi

cd ..

echo ""
echo "=== DONE ==="
echo "Next: Run ./test_workings.sh to QA"

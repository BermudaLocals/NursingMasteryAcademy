For educational purposes only. Not an accredited nursing program, not affiliated with NCSBN, ANCC, or any Board of Nursing. Does not provide licensure, CEUs, clinical hours, or qualification to sit for NCLEX. Advanced Clinical Reasoning Vault is for educational reasoning only, not medical advice.

Certificate: Certificate of Completion - Simulation Training. Non-accredited. Does not provide licensure or qualify you to sit for NCLEX.

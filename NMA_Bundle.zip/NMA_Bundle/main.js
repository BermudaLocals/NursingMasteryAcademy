// Nursing Mastery Academy - Clinical Brain v2 US Compliant
const NCSBN_STEPS=["Recognize Cues","Analyze Cues","Prioritize Hypotheses","Generate Solutions","Take Action","Evaluate Outcomes"];
let currentStep=0;
function directorSpeak(text,step){
  const fallback=document.getElementById('director-text-fallback');
  const status=document.getElementById('director-status');
  if(fallback){fallback.innerText=`[${step||NCSBN_STEPS[currentStep]}] ${text}`; fallback.style.display='block';}
  if(status) status.innerText=`Step: ${step||NCSBN_STEPS[currentStep]}`;
  if('speechSynthesis' in window){
    try{ speechSynthesis.cancel(); speechSynthesis.speak(new SpeechSynthesisUtterance(text)); }catch(e){console.log('Voice failed, text fallback used',e);}
  }
}
function checkRedZone(v){const r=[]; if(v.spo2<90)r.push('O2 <90% RED ZONE'); if(v.sbp<90||v.sbp>180)r.push('BP RED ZONE'); if(v.hr<50||v.hr>120)r.push('HR RED ZONE'); if(v.temp>101.5)r.push('Temp RED ZONE'); return r;}
function check5Rights(order,admin){const e=[]; if(order.patient!==admin.patient)e.push('Right Patient'); if(order.drug!==admin.drug)e.push('Right Drug'); if(order.dose!==admin.dose)e.push('Right Dose'); if(order.route!==admin.route)e.push('Right Route'); return e;}
document.addEventListener('DOMContentLoaded',()=>{directorSpeak('Welcome to the practice gym. We practice clinical judgment aligned to NCSBN model. Not a nursing program.','Recognize Cues');});

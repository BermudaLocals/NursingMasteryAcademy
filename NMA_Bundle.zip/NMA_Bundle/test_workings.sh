#!/bin/bash
# Nursing Mastery Academy - Agents QA Bash to Test All Workings
# Tests: Legal compliance, tier structure, tech, SEO, accessibility
# Run after deploy_to_github.sh or in CI

set -e

WORK_DIR="nursingmasteryacademy"
GREEN='\033[0;32m'
RED='\033[0;31m'
YELLOW='\033[1;33m'
NC='\033[0m'

cd $WORK_DIR 2>/dev/null || { echo "Run from parent or cd into $WORK_DIR"; cd .; }

echo "=== NMA QA AGENT - Testing All Workings ==="
echo "Date: $(date)"
echo ""

FAIL=0
PASS=0

function pass() { echo -e "${GREEN}[PASS]${NC} $1"; PASS=$((PASS+1)); }
function fail() { echo -e "${RED}[FAIL]${NC} $1"; FAIL=$((FAIL+1)); }
function warn() { echo -e "${YELLOW}[WARN]${NC} $1"; }

# 1. BANNED TERMS CHECK - FTC / Board risk
echo "--- 1. Banned Terms Scan (FTC/State Board liability) ---"
BANNED=("Accelerated Nursing Degree" "Starter Doctor Course" "Digital Residency" "Credential of Excellence" "Doctor's Vault" "Gold Standard in Accelerated" "wannabe doctors" "Chief Clinical Officer.*certif")
for term in "${BANNED[@]}"; do
  if grep -r -i -q "$term" --include="*.html" --include="*.md" --include="*.js" . 2>/dev/null; then
    fail "Banned term still present: '$term' - REMOVE or you risk AG complaint"
    grep -r -i -n "$term" --include="*.html" --include="*.md" --include="*.js" . | head -5
  else
    pass "Banned term clean: '$term'"
  fi
done
echo ""

# 2. REQUIRED LEGAL TERMS
echo "--- 2. Required Legal Disclaimers ---"
REQUIRED=("For educational purposes only" "Not an accredited" "Not affiliated with NCSBN" "Does not provide licensure" "Certificate of Completion" "Non-accredited" "not medical advice")
for term in "${REQUIRED[@]}"; do
  if grep -r -q "$term" --include="*.html" --include="*.md" . 2>/dev/null; then
    pass "Required disclaimer present: '$term'"
  else
    fail "Missing required disclaimer: '$term' - Add to footer + certificate"
  fi
done
echo ""

# 3. TIER STRUCTURE CHECK
echo "--- 3. 3-Tier Architecture Check ---"
if grep -q "Foundations Academy" index.html && grep -q "\$97" index.html; then pass "Tier 1 Foundations \$97 found"; else fail "Tier 1 missing"; fi
if grep -q "Clinical Mastery" index.html && grep -q "NCSBN\|Clinical Judgment" index.html; then pass "Tier 2 Clinical Mastery + NCSBN mapping found"; else fail "Tier 2 or NCSBN mapping missing"; fi
if grep -q "Advanced Clinical Reasoning Vault" index.html && grep -q "Pro Vault\|\$497" index.html; then pass "Tier 3 Pro Vault renamed from Doctor's Vault"; else fail "Tier 3 rename missing - must not be Doctor's Vault"; fi
if grep -q "7 Avatars\|Pre-Nursing\|CNA Student\|LPN\|RN Student\|New Grad\|Charge Nurse\|RN to BSN" README.md; then pass "7 avatars documented"; else warn "7 avatars not fully documented in README"; fi
echo ""

# 4. TECH - main.js iOS fallback
echo "--- 4. Tech - Web Speech API + iOS Fallback ---"
if grep -q "speechSynthesis.*in window" main.js && grep -q "director-text-fallback\|text fallback" main.js; then
  pass "main.js has speechSynthesis check + text fallback for iOS Safari"
else
  fail "main.js missing iOS fallback - 70% of students on iPhone will see blank director"
fi
if grep -q "NCSBN_STEPS\|Recognize Cues" main.js; then pass "main.js mapped to NCSBN CJMM"; else fail "main.js not mapped to NCSBN model"; fi
if grep -q "checkRedZone\|Triage Engine" main.js; then pass "Triage Engine present"; else warn "Triage Engine missing"; fi
if grep -q "check5Rights\|Med-Safety" main.js; then pass "Med-Safety Loop present"; else warn "Med-Safety Loop missing"; fi
echo ""

# 5. SEO CHECK
echo "--- 5. SEO Keywords Check ---"
BAD_SEO=("Accelerated Nursing Degree" "Starter Doctor Course")
GOOD_SEO=("NCLEX prep" "clinical judgment practice" "nursing simulation" "TEAS prep" "CNA exam prep")
for term in "${BAD_SEO[@]}"; do
  if grep -r -q "$term" --include="*.html" .; then fail "Bad SEO still in index.html: $term"; else pass "Bad SEO removed: $term"; fi
done
for term in "${GOOD_SEO[@]}"; do
  if grep -r -q "$term" --include="*.html" --include="*.md" .; then pass "Good SEO present: $term"; else warn "Good SEO missing: $term - add to footer"; fi
done
echo ""

# 6. Files existence
echo "--- 6. File Structure ---"
[ -f "index.html" ] && pass "index.html exists" || fail "index.html missing"
[ -f "main.js" ] && pass "main.js exists" || fail "main.js missing"
[ -f "style.css" ] && pass "style.css exists" || warn "style.css missing (check artifact)"
[ -f "legal/disclaimer.md" ] && pass "legal/disclaimer.md exists" || fail "legal/disclaimer.md missing"
[ -f "curriculum/curriculum_map.json" ] && pass "curriculum_map.json exists" || fail "curriculum_map.json missing"
echo ""

# 7. Mobile / Accessibility quick checks
echo "--- 7. Mobile & Accessibility ---"
if grep -q "viewport.*width=device-width" index.html; then pass "Viewport meta for mobile"; else fail "Missing viewport meta"; fi
if grep -q "director-text-fallback\|aria\|WCAG" index.html || grep -q "WCAG\|accessibility" main.js; then pass "Accessibility fallback noted"; else warn "Add WCAG/accessibility note for ADA compliance"; fi
echo ""

# 8. Spanish / Multi-language liability
echo "--- 8. Global Multi-Language Engine Check ---"
if grep -r -q "verified by.*medical translator\|Verified" --include="*.html" --include="*.md" .; then
  pass "Medical translation verification noted (liability protection)"
else
  warn "Add 'verified by medical translator' for Spanish dosage - liability risk"
fi
echo ""

# 9. Simulate user flows (agent actions)
echo "--- 9. Simulated User Flows ---"
echo "Simulating: Pre-Nursing searches TEAS -> Tier 1"
grep -q "TEAS prep" index.html && pass "Flow 1: Pre-Nursing finds TEAS" || fail "Flow 1 broken"

echo "Simulating: ADN student failing 2nd sem -> Tier 2 NGN"
grep -q "Prioritize Hypotheses\|Bow-tie\|Trend" index.html && pass "Flow 2: ADN student finds NGN practice" || fail "Flow 2 broken"

echo "Simulating: New Grad needs charge nurse"
grep -q "Rapid Response\|Code Blue\|SBAR" index.html && pass "Flow 3: Charge nurse scenarios found" || fail "Flow 3 broken"

echo "Simulating: CNA challenge state rules"
grep -q "states that allow\|Check your state" legal/disclaimer.md && pass "Flow 4: CNA challenge disclaimer" || fail "Flow 4 missing state rule disclaimer"
echo ""

# Summary
echo "=========================================="
echo -e "QA Results: ${GREEN}$PASS passed${NC}, ${RED}$FAIL failed${NC}"
if [ $FAIL -eq 0 ]; then
  echo -e "${GREEN}✓ ALL WORKINGS PASS - Safe to market in US as supplemental prep${NC}"
  echo "Next: Form WY/DE LLC, get 2 US RN reviewers, Stripe, TikTok/Reels"
else
  echo -e "${RED}✗ $FAIL checks failed - fix before selling in US${NC}"
  echo "Fix banned terms first - FTC/AG risk"
fi
echo "=========================================="

# Optional: Run lighthouse / html validator if installed
if command -v npx &> /dev/null; then
  echo ""
  echo "Tip: Run npx lighthouse index.html --view for perf check (optional)"
fi

exit $FAIL
